import pandas as pd
import os

# Main Goal: Output a Cleaned Version of a Dataset.

# Task 1: Write a function that sorts through the dataset, given a group of headers
# - Account for Errors (i.e. output a result message and the file in case thats what they wanted anyways)
# - Take a few parameters: PivotColumn?
# - Split/Merge Columns

def InputDirectory():
    while True:
        filepath = input("Input the input folder path: ")
        if os.path.exists(filepath):
            return filepath
        print("FILE DIRECTORY DOES NOT EXIST")

def OutputDirectory():
    fileiteration = 1
    while True:
        try:
            directory = input("Input the directory of where the folder should be: ")
            folderpath = input("Input the folder's name: ")
            os.mkdir(fr"{directory}\{folderpath}")
            break
        except FileExistsError:
            if fileiteration == 1:
                folderpath += " (1)"
            else:
                start, end = folderpath.rsplit(f"{fileiteration}", 1)
                folderpath = start + f"{fileiteration}" + end
            fileiteration+=1
    return fr"{directory}\{folderpath}"

# Filters headers and pivots the columns
def FilterHeaders(database: pd.DataFrame) -> pd.DataFrame:
    headerstokeep= []
    while True:
        header = input("Input a header (exit to stop): ")
        if header == "exit":
            break
        else:
            headerstokeep.append(header)
    while True:
        pivotcolumn = input("Do you want to transpose the data (Yes/No): ")
        if pivotcolumn in ("Yes", "No"):
            break
        else:
            print("NOT YES/NO")
    database.dropna(how = "all", inplace = True)
    if pivotcolumn == "Yes":
        pd.pivot_table(database)
    database.filter(items = headerstokeep)
    return database

# Combine and Split Headers/Specific type of Parameter (default split is " ")
def SplitMergeColumn(database: pd.DataFrame, split = True) -> pd.DataFrame:
    try:
        if split:
            mainheader = input("Input the header to split: ")
            partition = input("Input the column partition: ")
            header1 = input("Input the first header: ")
            header2 = input("Input the second header: ")
            database[[header1, header2]] = database[mainheader].str.split(partition, expand = True)
        else:
            header1 = input("Input the first header: ")
            header2 = input("Input the second header: ")
            mainheader = input("Input the merged header: ")
            database[mainheader] = database[header1].astype(str) + database[header2].astype(str)   
        return database
    except AttributeError:
        print("mainheader DOES NOT EXIST" if split else "header1 or header2 DO NOT EXIST")
        return database
