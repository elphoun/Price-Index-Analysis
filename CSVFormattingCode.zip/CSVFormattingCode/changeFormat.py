import pandas as pd
import os

directoryname = "NewData"

# main loops through all of the csv's and then creates their files. 
def main():
    global directoryname
    filenum = 2
    while True:
        try:
            os.mkdir(fr"PowerBI\{directoryname}")
            break
        except FileExistsError:
            if directoryname == "NewData":
                directoryname = "NewData1"
            else:
                directoryname.replace(f"{filenum-1}", f"{filenum}")
                filenum += 1
    listofCSV = ["ConsumerCPI", "EnergyPi", "FoodPI", "HeadlineCPI", "ProducerCPI"]
    for filename in listofCSV:
        makeFile(processCSV(filename), f"new{filename}.csv")
        
# makeFile creates the file from
def makeFile(csv: pd.DataFrame, filename: str) -> __file__:
    csv.to_csv(fr"C:\Users\kalem\OneDrive\Desktop\Coding\PowerBI\{directoryname}\{filename}", header=csv.columns)
        
# processCSV outputs the DataFrame after being cleaned        
def processCSV(filename: str) -> pd.DataFrame:
    csv = pd.read_csv(rf"C:\Users\kalem\OneDrive\Desktop\Coding\PowerBI\UnformattedData\{filename}.csv")
    csv = csv.dropna(how = "all")
    months = list(filter(lambda x: "19701" <= x <= "20234", csv.columns))
    csv = csv.filter(items = ["Country Code", "Country"] + months)
    csv.rename(lambda x: f"{x[:4]}-{x[4:]}-01" if x.isnumeric() else x, axis = "columns", inplace = True)
    return csv

if __name__ == "__main__":
    main()
    