import pandas as pd
import os
import adjustformat

def getCSV():
    inputdirectory = adjustformat.InputDirectory()
    outputdirectory = adjustformat.OutputDirectory()
    for file in os.listdir(inputdirectory):
        csv = pd.read_csv(fr"{inputdirectory}\{file}")
        changedcsv = TakeCommands(csv)
        csv.to_csv(fr"{outputdirectory}\{file}", header=csv.columns)
        
def TakeCommands(database):
    instructions = "filter: filter a database using the given headers\nsplit: split a column in half\nmerge: merge two columns\ntype \"exit\" to exit: \n"
    print(instructions)
    while True:
            command = input()
            if command == "filter":
                database = adjustformat.FilterHeaders(database)
            elif command == "split":
                database = adjustformat.SplitMergeColumn(database, True)
            elif command == "merge":
                database = adjustformat.SplitMergeColumn(database, False)
            elif command == "exit":
                return database
            else:
                print("not valid")

getCSV()